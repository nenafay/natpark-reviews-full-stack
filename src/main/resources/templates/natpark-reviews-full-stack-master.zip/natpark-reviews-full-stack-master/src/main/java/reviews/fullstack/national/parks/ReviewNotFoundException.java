package reviews.fullstack.national.parks;

public class ReviewNotFoundException extends Exception {

}
